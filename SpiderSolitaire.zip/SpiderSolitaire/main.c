/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: admin
 *
 * Created on May 19, 2019, 1:32 PM
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "spider.h"
/*
 * 
 */

void seperate(void) {
    printf("\n");
    for (int i = 0; i < 10; i ++) {
        printf("--");
    }
    printf("\n");
}
int main(void) {
    int state = 1;
    printf("Welcome to Spider Solitaire\n");
    printf("Commands avaliable: M for move; P for print; R for reveal all card; S for get stock; and Q for quit\n");
    printf("For more detailed explanation and examples please see game_rule.txt;\n");
    seperate();
    printf("\n");
    while (state) {
        struct spider s = {};
        spider_init_random(&s);
        spider_print(&s);
        while (1) {
          seperate();
          printf("Please type you command:\n");
          char input;
          scanf(" %c", &input);
          if (input == 'p' || input == 'P') {
            // print
            seperate();
            printf("\n");
            spider_print(&s);
          } else if (input == 'r' || input == 'R') {
            // print all cards face up
            seperate();
            printf("\n");
            spider_print_faceup(&s);
          } else if (input == 's' || input == 'S') { 
            // get stock cards
            seperate();
            printf("\n");
            spider_get_stock(&s);
            // print
            spider_print(&s);
          }  else if (input == 'm' || input == 'M') {
            int src = 0;
            scanf("%d", &src);
            int card = 0;
            if (!read_card(&card)) {
                scanf(" %c", &input);
                continue;
            }
            int dest = 0;
            scanf("%d", &dest);

            // move
            spider_move(&s, src, card, dest);
            // print
            seperate();
            printf("\n");
            spider_print(&s);
            if (spider_has_won(&s)) {
                printf("Congratulations, you have won the game!\n");
                printf("Want to play another game? type Y or y for yes and any other for no \n");
                scanf(" %c", &input);
                if (input == 'y' || input == 'Y') {
                    state = 1;
                } else {
                    state = 0;
                }
                break;
            }
          } else if (input == 'q' || input == 'Q') {
              state = 0;
              printf("See you again! Quitting....!\n");
            break;
          } else {
          }
        }
    }
}
