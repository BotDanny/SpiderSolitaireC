/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "spider.h"
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

//=========================================================
// Game initialization
//=========================================================

static const int TABLEAU_SIZE = 10;
static const int DECK_SIZE = 13;
static const int NUM_DECK = 8;

// spider_init_stacks(s) initializes all
// the stacks in the spider struct. 
// requires: s is a valid pointer.
// effects: mutates *s
static void spider_init_stacks(struct spider *s) {
  stack_init(&s->stock);
  for (int i = 0; i < TABLEAU_SIZE; ++i) {
    stack_init(&s->tableau_up[i]);
    stack_init(&s->tableau_down[i]);
  }
}

// get_random_card(card_count) repeatedly generates
// a random card value from 1 to 13 until 
// the number of cards left for that value is 
// positive according to card_count.
// requires: card_count is a valid pointer.
//           length of card_count is 13.
static int get_random_card(int card_count[]) {
  assert(card_count);

  int card_random = rand() % DECK_SIZE + 1; //generate a car between 1-13
  while (card_count[card_random - 1] == 0) { //Check if the card being generated is used up
    card_random = rand() % DECK_SIZE + 1;
  }
  return card_random;
}

// init_tableau(s,index,num_down,num_up,card_count)
// initialize the index-th tableau randomly by 
// putting num_down cards in the face-down pile and
// num_up cards in the face-up pile.
// requires: s and card_count are valid pointers.
//           0 <= index <= 9
//           4 <= num_down <= 5
//           num_up == 1
//           length of card_count is 13.
// effects: mutates *s
static void init_tableau(struct spider *s, 
                         int index, 
                         int num_down, 
                         int num_up, 
                         int card_count[]) {
  assert(s);
  assert(card_count);
  assert(0 <= index);
  assert(index <= 9);
  assert(num_down == 4 || num_down == 5);
  assert(num_up == 1);

  for (int j = 0; j <= num_down - 1; ++j) {
    int card_random = get_random_card(card_count);
    stack_push(card_random, &s->tableau_down[index]);
    --card_count[card_random - 1];
  }
  for (int j = 0; j <= num_up - 1; ++j) {
    int card_random = get_random_card(card_count);
    stack_push(card_random, &s->tableau_up[index]);
    --card_count[card_random - 1];
  }
}

void spider_init_random(struct spider *s) {
  assert(s);

  const int STOCK_SIZE_INITIAL = 50;

  int card_count[13];
  for (int i = 0; i < DECK_SIZE; ++i) {
    card_count[i] = 8;
  }

  srand(time(0));

  // initialize the stacks
  spider_init_stacks(s); 

  // init stock pile
  s->stock_size = STOCK_SIZE_INITIAL;
  for (int i = 0; i < STOCK_SIZE_INITIAL; ++i) {
    int card_random = get_random_card(card_count);
    stack_push(card_random, &s->stock);
    --card_count[card_random - 1];
  }

  // init the tableaus
  for (int i = 0; i < 4; ++i) {
    init_tableau(s, i, 5, 1, card_count);
  }
  for (int i = 4; i <= TABLEAU_SIZE - 1; ++i) {
    init_tableau(s, i, 4, 1, card_count);
  }

  s->comp_decks = 0;
}

bool spider_has_won(const struct spider *s) {
  assert(s);

  return (s->comp_decks == NUM_DECK);
}

//=========================================================
// Implement the functions below.
//=========================================================

// stack_length(s) returns the number of element in s;
int stack_length (struct stack s) {
  int length = 0;
  while (!stack_is_empty(&s)) {
    length++;
    stack_pop(&s);
  }
  return length;
}

// read_card(card_read) reads at most two characters representing
// the value of a playing card.  If the first character is E(end),
// then it returns true.  Otherwise, it returns false and
// mutates *card_read to be the integer value of the card.
// A is read as 1, J is read as 11, 
// Q is read as 12 and K is read as 13.
// If an error occurs reading in the value, the function
// prints out an error message and terminates the program.
// effects: reads input and modifies *card_read
// require: card_read is a valid pointer
bool read_card(int *card_read) {
  assert(card_read);
  char input;
  scanf(" %c", &input);
  if (input == '1') {
    char input2;
    scanf("%c", &input2);
    if (input2 == '0') {
      *card_read = 10;
    } else {
      printf("Error reading in a card.\n");
      return false;
    }
  } else if (input == 'A') {
    *card_read = 1;
  } else if (input >= '2' && input <= '9') {
    *card_read = input - '0'; 
  } else if (input == 'J') {
    *card_read = 11;
  } else if (input == 'Q') {
    *card_read = 12;
  } else if (input =='K') {
    *card_read = 13;
  } else {
    printf("Error reading in a card.\n");
    return false;
    
  }
  return true;
}

// spider_get_stock(s) removes 10 cards from the stock pile
// and places 1 card face-up on top of each tableau pile.
// effects: may produce output and may mutate *s
// require: s is a valid pointer
void spider_get_stock(struct spider *s) {
  assert(s);
  if (s->stock_size <= 0) {
    printf("Error getting cards from the stock.\n");
    return;
  }
  for (int i = 0; i < TABLEAU_SIZE; i++) {
    if (stack_is_empty(&s->tableau_down[i]) && 
        stack_is_empty(&s->tableau_up[i])) {
      printf("Error getting cards from the stock.\n");
      return;
    }
  }
  for (int j = 0; j < TABLEAU_SIZE; j++) {
    stack_push(stack_pop(&s->stock), &s->tableau_up[j]);
  }
  s->stock_size -= TABLEAU_SIZE;
}

// spider_find_seq(s_src_up,temp,card) attempts
// to find a descending sequence of cards starting 
// with the provided card on top of s_src_up.  
// If such a sequence does not exist, 
// this function finds the longest descending sequence
// of cards on top of s_src_up.  After finding
// such a sequence, the function moves this sequence
// to temp in reverse order.  Then, the function
// returns true if the descending sequence ends with 
// the provided card.  It returns false otherwise.
// requires: s_src_up is non-empty.
//           s_src_up and temp are valid pointers.
//           1 <= card <= 13
static bool spider_find_seq(struct stack *s_src_up, 
                            struct stack *temp,
                            int card) {
  assert(s_src_up);
  assert(temp);
  assert(!stack_is_empty(s_src_up));
  assert(card <= 13);
  assert(card >= 1);
  const int length = stack_length(*s_src_up);
  int next = -1;
  for (int i = 0; i < length; i++) {
    int current = stack_pop(s_src_up);
    stack_push(current, temp);
    if (current == card) {
      return true;
    }
    if (!stack_is_empty(s_src_up)) {
      next = stack_top(s_src_up);
      if (next - current != 1) {
        break;
      }
    } 
  }
  return false;
}

// turn_face_up(s) checks if there are no face-up cards in a tableau
// If yes, a face=down card is turned up.
// effects: may modify s
// require: s is a valid pointer
void turn_face_up(struct spider *s) {
  assert(s);
  for (int i = 0; i < TABLEAU_SIZE; i++) {
    if (stack_is_empty(&s->tableau_up[i]) && 
        !stack_is_empty(&s->tableau_down[i])) {
      stack_push(stack_pop(&s->tableau_down[i]), &s->tableau_up[i]);
    }
  }
}

// complete_deck(column) checks if a tableau has a complete deck
// If yes, the deck is removed from the tableau and
// the number of completed decks increase by 1;
// effects: may modify column;
// require: column is a valid pointer
bool complete(struct stack *column) {
  assert(column);
  int length = stack_length(*column);
  int next = -1;
  if (length >= DECK_SIZE && stack_top(column) == 1) {
    for (int i = 0; i < length; i++) {
      int current = stack_pop(column);
      if (current == DECK_SIZE) {
        return true;
      }
      if (!stack_is_empty(column)) {
        next = stack_top(column);
        if (next - current != 1) {
          break;
        }
      } 
    }
  }
  return false;
}

// complete_deck(s) checks if any complete deck is face-up and on top of a 
// tableau pile. If yes, the deck is removed from the tableau and
// the number of completed decks increase by 1;
// effects: may modify s;
// require: s is a valid pointer
void complete_deck(struct spider *s) {
  assert(s);
  for (int i = 0; i < TABLEAU_SIZE; i++) {
    struct stack temp = s->tableau_up[i];
    if (complete(&temp)) {
      spider_find_seq(&s->tableau_up[i], &temp, 13);
      s->comp_decks += 1;
    }
  }
}

// spider_move(s, src, card, dest) attempts to move a sequence
// of cards from the src tableau pile to the dest tableau pile.
// The bottom card in the sequence must have the provided card
// number.  Otherwise, it displays an error message.
// effects: produces output and may mutate *s
// requires: 1 <= card <= 13.
//           s is valid pointers.
//           0 <= scr and dest <= 9
void spider_move(struct spider *s, 
                 int src, int card, int dest) {
  assert(s);
  if (src == dest) {
    return;
  }
  struct stack temp1 = s->tableau_up[src];
  struct stack temp2 = {};
  stack_init(&temp2);
  if (stack_is_empty(&temp1) || !spider_find_seq(&temp1, &temp2, card)) {
    printf("Invalid move.\n");
    return;
  }
  int dest_top;
  int moved_stack_first = stack_top(&temp2);
  if (stack_is_empty(&s->tableau_up[dest])) {
    dest_top = 0;
  } else {
    dest_top = stack_top(&s->tableau_up[dest]);
  }
  if (dest_top == 0 ||
      (stack_length(temp2) == 1 && dest_top > moved_stack_first) ||
      (stack_length(temp2) > 1 && dest_top == moved_stack_first + 1)) {
    struct stack temp3 = {};
    stack_init(&temp3);
    spider_find_seq(&s->tableau_up[src], &temp3, card);
    const int temp3_len = stack_length(temp3);
    for (int i = 0; i < temp3_len; i++) {
      stack_push(stack_pop(&temp3), &s->tableau_up[dest]); //
    }
    turn_face_up(s);
    complete_deck(s);
  } else {
    printf("Invalid move.\n");
    return;
  }
}

// translate(n) translates a integer into a string
// effect: produce output
void translate(int n) {
  if (n == 10) {
    printf("10");
  } else if (n == 1) {
    printf("A");
  } else if (n == 11) {
    printf("J");
  } else if (n == 12) {
    printf("Q");
  } else if (n == 13) {
    printf("K");
  } else {
    printf("%d", n);
  } 
}

// reverse_tab(s, len, index) returns th element at s[index].
// require: len > 0
int reverse_tab(struct stack s, int len, int index) {
  int top = stack_top(&s);
  for (int i = len - 1; i > index; i--) {
    stack_pop(&s);
    top = stack_top(&s);
  }
  return top;
}

// This function is for your own testing and debugging.  
// We will not test this function.
// spider_print_faceup(s) prints out the status of 
// the game with all the cards face up.
// all the cards in the stock pile are printed out.
// the cards in each tableau are printed out face up.
// effects: produces output
// require: s is a valid pointer
void spider_print(struct spider *s) {
  assert(s);
  turn_face_up(s);
  complete_deck(s);
  printf("The number of cards left in the stock pile: %d\n", s->stock_size);
  printf("The number of completed decks: %d\n", s->comp_decks);
  for (int i = 0; i < TABLEAU_SIZE; i++) {
    printf("%d: ", i);
    for (int j = 0; j < stack_length(s->tableau_down[i]); j++) {
      printf("_ ");
    }
    const int tab_length = stack_length(s->tableau_up[i]);
    for (int k = 0; k < tab_length; k++) {
      if (k) {
        printf(" ");
      }
      translate(reverse_tab(s->tableau_up[i],tab_length ,k));
    }
    printf("\n");
  }
}

void spider_print_faceup(struct spider *s) {
  assert(s);
  printf("The number of cards left in the stock pile: %d\n", s->stock_size);
  printf("The number of completed decks: %d\n", s->comp_decks);
  for (int i = 0; i < TABLEAU_SIZE; i++) {
    printf("%d: ", i);
    for (int j = 0; j < stack_length(s->tableau_down[i]); j++) {
      if (j) {
        printf(" ");
      }
      translate(reverse_tab(s->tableau_down[i], 
                            stack_length(s->tableau_down[i]),j));
    }
    printf(" ");
    const int tab_length = stack_length(s->tableau_up[i]);
    for (int k = 0; k < tab_length; k++) {
      if (k) {
        printf(" ");
      }
      translate(reverse_tab(s->tableau_up[i], 
                            stack_length(s->tableau_up[i]),k));
    }
    printf("\n");
  }
}
